"""
========================================================

Fichier :
serializers.py

Description :
Module de l'application Zemy.

Projet :
Zemy

========================================================
"""
from api.models import Payment
from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers
from .models import User, Vehicle, UserPreference, Ride, Booking, Conversation, Message, Notification, FinancialSettings, RefundRequest, Transaction, Parcel, SupportTicket, DriverPayout

class UserPreferenceSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour les préférences utilisateur (musique, bagages, animaux).
    """
    class Meta:
        model = UserPreference
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour le modèle User.
    Gère l'affichage des informations utilisateur et inclut des champs calculés
    tels que le nombre de trajets et les véhicules possédés.
    """
    preference = UserPreferenceSerializer(read_only=True)
    vehicles = serializers.SerializerMethodField()
    rides_count = serializers.SerializerMethodField()
    verification_status = serializers.SerializerMethodField()
    # Nombre de trajets effectués en tant que passager (proxy pour les avis)
    reviews_count = serializers.SerializerMethodField()
    # Total FCFA dépensé en covoiturage (trajets completés en tant que passager)
    total_spent = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id', 'full_name', 'email', 'phone', 'country', 'avatar',
            'rating', 'parcels_completed', 'parcel_rating',
            'is_verified', 'is_active', 'created_at',
            'preference', 'vehicles',
            'rides_count', 'reviews_count', 'total_spent',
            'verification_status',
        ]

    @extend_schema_field(dict)
    def get_vehicles(self, obj):
        return VehicleSerializer(obj.vehicles.all(), many=True).data

    @extend_schema_field(int)
    def get_rides_count(self, obj):
        """Nombre de trajets complétés en tant que conducteur."""
        return obj.rides_driven.filter(status='completed').count()

    @extend_schema_field(int)
    def get_reviews_count(self, obj):
        """
        Nombre de réservations complétées en tant que passager.
        Utilisé comme proxy pour le nombre d'avis.
        """
        return obj.bookings.filter(status='completed').count()

    @extend_schema_field(int)
    def get_total_spent(self, obj):
        """
        Total FCFA dépensé par l'utilisateur en covoiturage
        (somme des prix des réservations complétées).
        """
        from django.db.models import Sum, F, ExpressionWrapper, IntegerField
        result = obj.bookings.filter(status='completed').aggregate(
            total=Sum(
                ExpressionWrapper(
                    F('seats_booked') * F('ride__price_per_seat'),
                    output_field=IntegerField()
                )
            )
        )
        return result['total'] or 0


    @extend_schema_field(str)
    def get_verification_status(self, obj):
        if obj.is_verified:
            return 'verified'
        from .models import VerificationRequest
        existing = VerificationRequest.objects.filter(user=obj).first()
        if existing:
            if existing.status == 'approved':
                return 'verified'
            elif existing.status == 'rejected':
                return 'rejected'
            else:
                return 'pending'
        return 'not_verified'

class CompactUserSerializer(serializers.ModelSerializer):
    """
    Sérialiseur léger pour le modèle User utilisé comme relation imbriquée (N+1 queries optimization).
    """
    rides_count = serializers.SerializerMethodField()
    vehicles = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id', 'full_name', 'phone', 'avatar', 'rating', 'is_verified', 'rides_count', 'vehicles'
        ]

    @extend_schema_field(int)
    def get_rides_count(self, obj):
        return obj.rides_driven.filter(status='completed').count()

    @extend_schema_field(dict)
    def get_vehicles(self, obj):
        return VehicleSerializer(obj.vehicles.all(), many=True).data

class AdminUserSerializer(serializers.ModelSerializer):
    """
    Sérialiseur complet du modèle User pour le tableau de bord administrateur.
    Inclut des champs sensibles et toutes les informations.
    """
    password = serializers.CharField(write_only=True, required=False, allow_blank=True)
    archived_by_name = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id', 'full_name', 'email', 'phone', 'avatar', 'rating', 
            'is_verified', 'is_active', 'is_staff', 'created_at', 'password',
            'is_archived', 'archived_at', 'archive_reason', 'archived_by_name'
        ]
        read_only_fields = ['id', 'created_at', 'rating', 'archived_at', 'archived_by_name']

    def get_archived_by_name(self, obj):
        if obj.archived_by:
            return obj.archived_by.full_name or obj.archived_by.phone
        return None

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        user = User(**validated_data)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save()
        return user

    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        if password:
            instance.set_password(password)
        instance.save()
        return instance

class VehicleSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour le modèle Vehicle.
    Gère la création et mise à jour des véhicules d'un conducteur.
    """
    class Meta:
        model = Vehicle
        fields = '__all__'
        # BUG-009 FIX : 'owner' en lecture seule pour éviter le Mass Assignment.
        # La valeur est définie dans VehicleViewSet.perform_create() via request.user.
        read_only_fields = ['owner']


class RideSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour le modèle Ride (Trajet).
    Valide les lieux de départ/arrivée, les prix et les options de colis.
    Inclus les relations imbriquées (conducteur, véhicule) en lecture.
    """
    driver_details = CompactUserSerializer(source='driver', read_only=True)
    vehicle_details = VehicleSerializer(source='vehicle', read_only=True)

    class Meta:
        model = Ride
        fields = '__all__'
        read_only_fields = ['driver', 'price_per_seat', 'zemy_commission']

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        ret['original_price_per_seat'] = instance.price_per_seat
        
        # Filtrer pour exclure les escales générées automatiquement (is_driver = False)
        if 'stopovers' in ret and isinstance(ret['stopovers'], list):
            ret['stopovers'] = [s for s in ret['stopovers'] if isinstance(s, dict) and s.get('is_driver', True)]

        request = self.context.get('request')
        if request:
            query_params = request.query_params if hasattr(request, 'query_params') else getattr(request, 'GET', {})
            departure = query_params.get('departure')
            destination = query_params.get('destination')
            if departure and destination:
                segment_price = instance.get_segment_price(departure, destination)
                if segment_price:
                    ret['price_per_seat'] = segment_price
        return ret

class BookingSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour le modèle Booking (Réservation).
    Valide le nombre de places et expose les informations du passager.
    """
    passenger_details = CompactUserSerializer(source='passenger', read_only=True)
    ride_details = RideSerializer(source='ride', read_only=True)
    portion_price = serializers.SerializerMethodField()
    pricing_breakdown = serializers.SerializerMethodField()

    class Meta:
        model = Booking
        fields = '__all__'
        read_only_fields = [
            'passenger', 'status', 'payment_status', 'transaction_id',
            'custom_price', 'driver_counter_price', 'pickup_surcharge',
            'dropoff_surcharge'
        ]

    @extend_schema_field(int)
    def get_portion_price(self, obj):
        """Prix total payé par le passager (driver_price + commission)."""
        return obj.total_amount

    @extend_schema_field(dict)
    def get_pricing_breakdown(self, obj):
        """Décomposition complète du prix pour l'affichage frontend."""
        from .services.pricing_service import PricingService
        r = PricingService.compute_for_booking(obj)
        return {
            'driver_price': r.driver_price,
            'commission': r.commission,
            'total_to_pay': r.total_to_pay,
            'driver_amount': r.driver_amount,
            'zemy_amount': r.zemy_amount,
            'seats': r.seats,
        }

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        ride = getattr(instance, 'ride', None)
        if ride and hasattr(ride, 'waypoints'):
            wps = list(ride.waypoints.all().order_by('order'))
            if wps:
                dep_order = instance.departure_waypoint_order
                arr_order = instance.arrival_waypoint_order
                
                if dep_order is not None and 0 <= dep_order < len(wps):
                    if not ret.get('departure_location') or (dep_order > 0 and ret.get('departure_location') == ride.departure_location):
                        ret['departure_location'] = wps[dep_order].name or ride.departure_location
                        
                if arr_order is not None and 0 <= arr_order < len(wps):
                    if not ret.get('arrival_location') or (arr_order < len(wps) - 1 and ret.get('arrival_location') == ride.arrival_location):
                        ret['arrival_location'] = wps[arr_order].name or ride.arrival_location
            else:
                if not ret.get('departure_location'):
                    ret['departure_location'] = ride.departure_location
                if not ret.get('arrival_location'):
                    ret['arrival_location'] = ride.arrival_location
        return ret

class ParcelSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour la gestion de l'envoi de colis.
    """
    sender_user_details = UserSerializer(source='sender_user', read_only=True)
    ride_details = RideSerializer(source='ride', read_only=True)

    class Meta:
        model = Parcel
        fields = '__all__'
        read_only_fields = ['qr_code_data', 'zemy_commission', 'driver_payout']


class MessageSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour les messages (Textes, Images, Audio).
    """
    sender_details = UserSerializer(source='sender', read_only=True)
    attachment_url = serializers.SerializerMethodField()
    moderation_status = serializers.CharField(read_only=True)

    class Meta:
        model = Message
        fields = ['id', 'conversation', 'sender', 'sender_details', 'content',
                  'message_type', 'attachment', 'attachment_url',
                  'location_lat', 'location_lng', 'is_read', 'is_urgent', 'created_at', 'moderation_status']
        read_only_fields = ['sender', 'is_read', 'moderation_status']

    def create(self, validated_data):
        from .services.moderation_service import MessageModerator
        from .models import ModerationLog

        content = validated_data.get('content', '')
        moderation_status = 'accepted'
        moderation_result: dict = {}

        if content and validated_data.get('message_type', 'text') == 'text':
            moderation_result = MessageModerator.analyze_and_filter(content)
            moderation_status = moderation_result['status']

            if moderation_status in ['modified', 'blocked']:
                validated_data['content'] = moderation_result['filtered_content']

        # Save the message
        message = super().create(validated_data)

        # We temporarily store moderation_status on the instance to be used by the serializer representation
        message.moderation_status = moderation_status

        # Log if modified or blocked
        if moderation_status in ['modified', 'blocked'] and moderation_result:
            ModerationLog.objects.create(
                message=message,
                sender=message.sender,
                original_content=content,
                modified_content=moderation_result['filtered_content'],
                action_taken=moderation_status,
                detected_types=moderation_result['detected']
            )

        return message

    @extend_schema_field(str)
    def get_attachment_url(self, obj):
        request = self.context.get('request')
        if obj.attachment and hasattr(obj.attachment, 'url'):
            if request:
                return request.build_absolute_uri(obj.attachment.url)
            return obj.attachment.url
        return None

class ConversationSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour les conversations (Messagerie et Support).
    Expose le dernier message, le nombre de non-lus et l'urgence.
    """
    participant_1_details = UserSerializer(source='participant_1', read_only=True, allow_null=True)
    participant_2_details = UserSerializer(source='participant_2', read_only=True, allow_null=True)
    ride_details = RideSerializer(source='ride', read_only=True, allow_null=True)
    last_message = serializers.SerializerMethodField()
    unread_count = serializers.SerializerMethodField()
    has_urgent_unread = serializers.SerializerMethodField()
    booking_details = serializers.SerializerMethodField()

    class Meta:
        model = Conversation
        fields = '__all__'

    @extend_schema_field(dict)
    def get_booking_details(self, obj):
        if obj.conversation_type != 'ride' or not obj.ride:
            return None
        
        # Le passager est le participant qui n'est pas le conducteur (driver) du trajet.
        driver_id = obj.ride.driver_id
        passenger = None
        if obj.participant_1_id != driver_id:
            passenger = obj.participant_1
        elif obj.participant_2_id != driver_id:
            passenger = obj.participant_2
            
        if not passenger:
            return None
            
        booking = Booking.objects.filter(ride=obj.ride, passenger=passenger).first()
        if booking:
            return {
                'id': str(booking.id),
                'status': booking.status,
                'departure_location': booking.departure_location,
                'arrival_location': booking.arrival_location,
                'seats_booked': booking.seats_booked,
            }
        return None

    @extend_schema_field(dict)
    def get_last_message(self, obj):
        last_msg = obj.messages.order_by('-created_at').first()
        if last_msg:
            return MessageSerializer(last_msg, context=self.context).data
        return None

    @extend_schema_field(int)
    def get_unread_count(self, obj):
        request = self.context.get('request')
        if request and hasattr(request, 'user') and request.user.is_authenticated:
            return obj.messages.filter(is_read=False).exclude(sender=request.user).count()
        return 0

    @extend_schema_field(bool)
    def get_has_urgent_unread(self, obj):
        request = self.context.get('request')
        if request and hasattr(request, 'user') and request.user.is_authenticated:
            return obj.messages.filter(is_read=False, is_urgent=True).exclude(sender=request.user).exists()
        return False

class RegisterSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour l'inscription d'un nouvel utilisateur.
    Accepte le pays de l'utilisateur (code ISO 2 lettres) pour les marchés africains multi-pays.
    """
    password = serializers.CharField(write_only=True)
    # Code pays optionnel – défaut Bénin si non fourni
    country = serializers.CharField(max_length=5, required=False, default='BJ')
    
    class Meta:
        model = User
        fields = ['full_name', 'email', 'phone', 'password', 'country']
        
    def create(self, validated_data):
        # BUG-010 FIX : email doit être None (pas "") pour respecter la contrainte
        # UNIQUE nullable. Deux comptes sans email produisaient un IntegrityError
        # car email="" est traité comme une valeur en double par PostgreSQL.
        user = User.objects.create_user(
            phone=validated_data['phone'],
            email=validated_data.get('email') or None,
            full_name=validated_data.get('full_name', ''),
            country=validated_data.get('country', 'BJ'),
            password=validated_data['password']
        )
        return user

class LoginSerializer(serializers.Serializer):
    identifier = serializers.CharField()
    password = serializers.CharField(write_only=True)

class NotificationSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour les notifications (Alertes push FCM ou in-app).
    """
    user_details = UserSerializer(source='user', read_only=True)

    class Meta:
        model = Notification
        fields = '__all__'

class AppBrandingSerializer(serializers.ModelSerializer):
    class Meta:
        from .models import AppBranding
        model = AppBranding
        fields = '__all__'

class VerificationRequestSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour les demandes de vérification d'identité.
    Gère l'upload de photos (Selfie, CNI).
    """
    user_details = UserSerializer(source='user', read_only=True)
    
    class Meta:
        from .models import VerificationRequest
        model = VerificationRequest
        fields = '__all__'

class PromotionSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour les bannières promotionnelles (Dashboard Admin).
    """
    class Meta:
        from .models import Promotion
        model = Promotion
        fields = '__all__'

class MobileSettingsSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour les paramètres mobiles globaux.
    """
    class Meta:
        from .models import MobileSettings
        model = MobileSettings
        fields = '__all__'

class FinancialSettingsSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour les paramètres financiers (Commissions).
    """
    class Meta:
        model = FinancialSettings
        fields = '__all__'

class RefundRequestSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour les demandes de remboursement.
    """
    passenger_details = UserSerializer(source='passenger', read_only=True)
    driver_details = UserSerializer(source='driver', read_only=True)
    booking_details = BookingSerializer(source='booking', read_only=True)

    class Meta:
        model = RefundRequest
        fields = '__all__'

class TransactionSerializer(serializers.ModelSerializer):
    """
    Sérialiseur pour les transactions financières.
    """
    ride_details = RideSerializer(source='ride', read_only=True)

    class Meta:
        model = Transaction
        fields = '__all__'

class PopularPlaceSerializer(serializers.ModelSerializer):
    class Meta:
        from .models import PopularPlace
        model = PopularPlace
        fields = '__all__'


class SupportTicketSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupportTicket
        fields = '__all__'
        read_only_fields = ('id', 'ticket_number', 'status', 'created_at', 'updated_at', 'ip_address')

    def validate_message(self, value):
        from django.utils.html import strip_tags
        cleaned_value = strip_tags(value).strip()
        if len(cleaned_value) < 10:
            raise serializers.ValidationError("Le message doit contenir au moins 10 caractères.")
        return cleaned_value

    def validate(self, attrs):
        from django.utils.html import strip_tags
        if 'name' in attrs:
            attrs['name'] = strip_tags(attrs['name']).strip()
        if 'email' in attrs:
            attrs['email'] = strip_tags(attrs['email']).strip()
        if 'subject' in attrs:
            attrs['subject'] = strip_tags(attrs['subject']).strip()
        return attrs


class PaymentSerializer(serializers.ModelSerializer):
    user_details = UserSerializer(source='user', read_only=True)
    booking_details = BookingSerializer(source='booking', read_only=True)
    parcel_details = ParcelSerializer(source='parcel', read_only=True)

    class Meta:
        model = Transaction
        fields = '__all__'


class UserPaymentSerializer(serializers.ModelSerializer):
    """
    Serializer enrichi pour l'historique de paiements côté utilisateur mobile.
    Expose les détails du trajet ou du colis associé.
    """
    service_type = serializers.SerializerMethodField()
    service_label = serializers.SerializerMethodField()
    departure_location = serializers.SerializerMethodField()
    arrival_location = serializers.SerializerMethodField()
    departure_date = serializers.SerializerMethodField()
    booking_id = serializers.UUIDField(source='booking.id', read_only=True, allow_null=True)
    booking_status = serializers.CharField(source='booking.status', read_only=True, allow_null=True)
    driver_id = serializers.UUIDField(source='booking.ride.driver.id', read_only=True, allow_null=True)
    has_refund_request = serializers.SerializerMethodField()

    class Meta:
        model = Payment
        fields = [
            'id', 'transaction_id', 'amount', 'status', 'provider',
            'service_type', 'service_label', 'departure_location',
            'arrival_location', 'departure_date', 'created_at',
            'booking_id', 'booking_status', 'driver_id', 'has_refund_request',
        ]

    def get_has_refund_request(self, obj):
        if obj.booking:
            return obj.booking.refund_requests.exists()
        return False

    def get_service_type(self, obj):
        if obj.booking:
            return 'ride'
        if obj.parcel:
            return 'parcel'
        return 'other'

    def get_service_label(self, obj):
        if obj.booking and obj.booking.ride:
            ride = obj.booking.ride
            return f"{ride.departure_location} → {ride.arrival_location}"
        if obj.parcel:
            return "Livraison de colis"
        return "Service Zemy"

    def get_departure_location(self, obj):
        if obj.booking and obj.booking.ride:
            return obj.booking.ride.departure_location
        return None

    def get_arrival_location(self, obj):
        if obj.booking and obj.booking.ride:
            return obj.booking.ride.arrival_location
        return None

    def get_departure_date(self, obj):
        if obj.booking and obj.booking.ride:
            return obj.booking.ride.departure_date
        return None


class DriverPayoutSerializer(serializers.ModelSerializer):
    """
    Serializer pour les demandes de virement conducteur (dashboard admin).
    """
    driver_name = serializers.ReadOnlyField(source='driver.full_name')
    driver_email = serializers.ReadOnlyField(source='driver.email')
    driver_phone = serializers.ReadOnlyField(source='driver.phone')
    ride_route = serializers.SerializerMethodField()
    ride_date = serializers.ReadOnlyField(source='ride.departure_date')
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    operator_display = serializers.CharField(source='get_operator_display', read_only=True)
    payment_mode_display = serializers.CharField(source='get_payment_mode_display', read_only=True)

    class Meta:
        model = DriverPayout
        fields = [
            'id', 'driver', 'driver_name', 'driver_email', 'driver_phone',
            'ride', 'ride_route', 'ride_date',
            'amount', 'phone_number', 'operator', 'operator_display',
            'status', 'status_display',
            'payment_mode', 'payment_mode_display',
            'payout_reference', 'feexpay_reference',
            'admin_note', 'failure_reason', 'failure_code',
            'requested_at', 'processed_at', 'paid_at', 'failed_at',
        ]
        read_only_fields = ['id', 'payout_reference', 'requested_at']

    def get_ride_route(self, obj):
        if obj.ride:
            return f"{obj.ride.departure_location} → {obj.ride.arrival_location}"
        return ""

# updated

