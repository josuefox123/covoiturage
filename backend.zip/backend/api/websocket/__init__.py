# Zemy — websocket package initialization
